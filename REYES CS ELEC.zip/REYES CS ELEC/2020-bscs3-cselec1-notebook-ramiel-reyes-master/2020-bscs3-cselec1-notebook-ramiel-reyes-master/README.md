# 🐼 CS Elec 1 - Notebook
##### 3rd Year - Computer Science

## 🐼 What is this?

This repository contains Jupyter Notebooks for learning [pandas](https://github.com/pandas-dev/pandas).

## 🐼 What is pandas?

According to [pandas-dev](https://github.com/pandas-dev) 
> pandas is a Python package that provides fast, flexible, and expressive data structures designed to make working with "relational" or "labeled" data both easy and intuitive. It aims to be the fundamental high-level building block for doing practical, real world data analysis in Python. Additionally, it has the broader goal of becoming the most powerful and flexible open source data analysis / manipulation tool available in any language. It is already well on its way towards this goal.

## 📄 Dependencies

- [NumPy](https://numpy.org/)
- [pandas](https://github.com/pandas-dev/pandas)

## ⑂ Forking this repository

1. Create your own private repository under [CS Klasrum](https://github.com/CS-Klasrum);
2. Clone this repository;
```sh
git clone https://github.com/CS-Klasrum/cselec1-notebook
cd ./cselec1-notebook
```
3. Change `origin` remote;
```sh
git remote set-url origin "https://github.com/CS-Klasrum/link-to-your-repository"
```
4. Add `classroom` remote.
```sh
git remote add classroom "https://github.com/CS-Klasrum/cselec1-notebook"
```

## ⤵️ Pulling changes from this notebook

1. Pull the latest changes from this notebook;
```sh
git pull classroom master 
```
2. Update your personal repository.
```sh
git push origin master
```

## 📚 Table of Contents

1. [Python Crash Course](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/1%20-%20Python%20Crash%20Course.ipynb)
2. [What is NumPy?](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/2%20-%20Numpy%20Arrays.ipynb)
3. [Numpy Indexing & Selection](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/3%20-%20Numpy%20Array%20Indexing%20and%20Selection.ipynb)
4. [What is pandas?](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/4%20-%20pandas.ipynb)
5. pandas - DataFrame
    1. [pandas - DataFrame - Part 1](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/5%20-%20pandas%20-%20DataFrame.ipynb)
    2. [pandas - DataFrame - Part 2](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/5.1%20-%20pandas%20-%20DataFrame%20-%20Part%202.ipynb)
    3. [pandas - DataFrame - Part 3](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/5.2%20-%20pandas%20-%20DataFrame%20-%20Part%203.ipynb)
6. [pandas - Missing Values](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/6%20-%20pandas%20-%20Missing%20Values.ipynb)
7. [pandas - GroupBy](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/7%20-%20pandas%20-%20Groupby.ipynb)
8. [pandas - Concatenating DataFrames](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/8%20-%20pandas%20-%20Concatenating.ipynb)
9. [pandas - Merging DataFrames](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/9%20-%20pandas%20-%20Merging.ipynb)
10. [pandas - Joining DataFrames](https://github.com/CS-Klasrum/cselec1-notebook/blob/master/10%20-%20pandas%20-%20Joining.ipynb)

## 📄 License

This repository is exclusively available for the **3rd year students of Computer Science** ([College of Mary Immaculate](https://collegeofmaryimmaculate.edu.ph/)).
Sharing this code outside the class could lead to punishment or expulsion.
